// DART Event Auditor - Content Script
// Minimal content script - main injection is done by background.js

(function() {
    'use strict';
    console.log('[DART Extension] Content script loaded');
})();
